package com.example.simplelogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Browser;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import org.w3c.dom.Text;

import java.util.regex.Pattern;

import javax.net.ssl.CertPathTrustManagerParameters;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);
        MaterialButton loginbtn = findViewById(R.id.login);
        ImageView facebook = findViewById(R.id.facebook);
        ImageView twitter = findViewById(R.id.twitter);
        ImageView instagram = findViewById(R.id.instagram);
        TextView newAccount = findViewById(R.id.CreateAccount);
        DBHelper DB = new DBHelper(this);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String Email = email.getText().toString();
            String Password = password.getText().toString();

            if (Email.isEmpty() || Password.isEmpty()){
                Toast.makeText(MainActivity.this, "Please Enter Fields", Toast.LENGTH_SHORT).show();
                email.setText("");
                password.setText("");
            } else {
                Boolean checkemailpassword = DB.checkemailpassword(Email, Password);
                if (checkemailpassword==true){
                    Toast.makeText(MainActivity.this, "Login Success!", Toast.LENGTH_SHORT).show();
                    Intent welcome = new Intent(getApplicationContext(), welcome.class);
                    startActivity(welcome);
                    email.setText("");
                    password.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "invalid Email or Password!", Toast.LENGTH_SHORT).show();
                    email.setText("");
                    password.setText("");
                }
            }
            }
        });

        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent facebook = new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://www.facebook.com/login/"));
                startActivity(facebook);
            }
        });

        twitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent google = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.twitter.com"));
                startActivity(google);
            }
        });

        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent instagram = new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://www.instagram.com/"));
                startActivity(instagram);
            }
        });

        newAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent register = new Intent(getApplicationContext(), register.class);
                startActivity(register);
            }
        });
    }
}