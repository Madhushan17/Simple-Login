package com.example.simplelogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText registerEmail = findViewById(R.id.registerEmail);
        EditText registerPassword = findViewById(R.id.registerPassword);
        EditText ConfirmPassword = findViewById(R.id.ConfirmPassword);
        MaterialButton loginbtn = findViewById(R.id.loginbtn);
        DBHelper DB = new DBHelper(this);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = registerEmail.getText().toString();
                String password = registerPassword.getText().toString();
                String RePassword = ConfirmPassword.getText().toString();

                if (email.isEmpty() || password.isEmpty() || RePassword.isEmpty()) {
                    Toast.makeText(register.this, "Fill the Fields", Toast.LENGTH_SHORT).show();
                } else {
                    if (password.equals(RePassword)) {
                        Boolean checkemail = DB.checkemail(email);
                        if (checkemail == false) {
                            Boolean insert = DB.insertData(email, password);
                            if (insert == true) {
                                Toast.makeText(register.this, "Account Created!", Toast.LENGTH_SHORT).show();
                                Intent home = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(home);
                            } else {
                                Toast.makeText(register.this, "Failed!", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(register.this, "Account Already Exist!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(register.this, "Passwords not Matching", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}